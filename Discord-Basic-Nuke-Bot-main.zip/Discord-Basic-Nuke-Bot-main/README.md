# Basic Discord Nuke Bot
The destroying of Discord servers

# WARNING:
This bot is against Discord Term's of Service. I am not responsible if you, or your bot, get banned or any other actions taken by Discord. Use this product at your own risk.

## Features
* Default prefix is $
* Easy to read code. Configurable if you know what you're messing with.
* Updated to work with latest Discord (tested as of 11/9/2020)
* Deletes command from chat as soon as it's sent to be more stealthy

## Commands
* $secret will have the bot DM you all available commands and what they do
* $kall will kick every member from the server
* $ball will ban every member from the server
* $rall will rename every member in the server
* $mall will DM every member in the server. (Edit what that message is in the bot)
* $destroy will delete all channels, spam new ones, delete all roles, ban all members, and delete all emojis (in that order)
* $ping will DM you the current ping to the server
* $info will DM you information about a specific user (Will not DM you if a user is not specified)

## Steps to configure:

1. In your bot's Discord settings, enable "server members intent" in the bot category. Bot also needs administrator permissions in order to work.

2. Install Python (version 3.7), be sure to select "add to path" option.

3. Open command prompt and type in "pip install discord.py"

4. Open bot.py file in any editor you choose. I prefer Visual Studio Code

5. Insert your bot's token at the very bottom where it says "TOKEN" 

6. Run the file by opening a Command Prompt in the same directory as the file and typing "py bot.py"

# Enjoy
